module.exports = {
  OWNER: '+6285750296797',
  OPENAI_API_KEY: 'sk-...kh4A'
};
