const { default: makeWASocket, useSingleFileAuthState } = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const fs = require('fs');
const P = require('pino');
const sticker = require('./lib/sticker');
const ai = require('./lib/ai');
const downloader = require('./lib/downloader');
const config = require('./config');

const { state, saveState } = useSingleFileAuthState('./session/auth_info.json');

async function startBot() {
  const sock = makeWASocket({
    logger: P({ level: 'silent' }),
    printQRInTerminal: true,
    auth: state
  });

  sock.ev.on('creds.update', saveState);
  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === 'close') {
      if ((lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut) {
        startBot();
      }
    } else if (connection === 'open') {
      console.log('Bot is connected');
    }
  });

  sock.ev.on('messages.upsert', async ({ messages }) => {
    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;

    const from = msg.key.remoteJid;
    const text = msg.message.conversation || msg.message.extendedTextMessage?.text || '';

    // Cek prefix atau perintah
    if (text.startsWith('.')) {
      const command = text.split(' ')[0].slice(1);
      const args = text.split(' ').slice(1).join(' ');

      switch (command) {
        case 'sticker':
          return sticker.makeSticker(sock, msg);
        case 'ai':
          return ai.replyAI(sock, msg, args);
        case 'ytmp4':
          return downloader.ytmp4(sock, msg, args);
        default:
          sock.sendMessage(from, { text: 'Perintah tidak dikenal!' });
      }
    }
  });
}

startBot();
