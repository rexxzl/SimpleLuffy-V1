# **Simple Wabot** 
## kelebihan
```javascript
easy coding
welcome keren
free feature downloader && tools
antibot feature
support button
ai groq
hd image && video
No encrypt
```

## ⚙️ Settings Bot Check In ***( config.js )***


## 👨‍💻 How to install/run


```bash
$ git clone https://github.com/Fiisya/simple-wabot
$ cd simple-wabot
$ npm install
$ npm start
```

## ☘️ Example Features
Berikut cara menambahkan fitur pada bot ini

### Plugins

```javascript
Example 1
let handler = async (m, { conn, text, usedPrefix, command }) => 
{
 // your code
}
handler.help = ["help"]
handler.tags = ["tag"]
handler.command = ["command"]
module.exports = handler

Example 2

module.exports = {
     help: ["help"],
     tags: ["tags"],
     command: ["command"],
     code: async(m, { conn, usedPrefix,  command, text,  isOwner, isAdmin, isBotAdmin, isPrems, chatUpdate  }) => 
     {
   //your code
  } 
}
```
---  

## 📢 Jgn Lupa Follow Channel dan Join Group ya

<p>Follow Me    <a href="https://whatsapp.com/channel/0029Vb4fjWE1yT25R7epR110">Klik disini</a></p>

<p>Join This Group   <a href="https://kua.lat/gcbot">Klik disini</a></p>

---------

### Thanks To
[![Nazir](https://github.com/Nazir99inf.png?size=100)](https://github.com/Nazir99inf)
[![Wildan](https://github.com/neoxr.png?size=100)](https://github.com/neoxr)
[![syaii](https://github.com/LT-SYAII.png?size=100)](https://github.com/LT-SYAII)
[![Nurutomo](https://github.com/Nurutomo.png?size=100)](https://github.com/Nurutomo)
[![WhiskeySockets](https://github.com/WhiskeySockets.png?size=100)](https://github.com/WhiskeySockets/Baileys)
[![BochilGaming](https://github.com/BochilGaming.png?size=100)](https://github.com/BochilGaming)
#### Contributor
[![Fiisya](https://github.com/Fiisya.png?size=100)](https://github.com/Fiisya)

---------
